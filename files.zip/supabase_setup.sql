-- ============================================================
-- ASTRIO — Full Supabase Database Setup
-- Paste into Supabase SQL Editor and click Run
-- ============================================================

-- 1. PROFILES
create table if not exists profiles (
  id              uuid references auth.users(id) on delete cascade primary key,
  username        text unique not null,
  display_name    text,
  bio             text    default '',
  avatar_url      text    default '',
  posts_count     integer default 0,
  followers_count integer default 0,
  following_count integer default 0,
  created_at      timestamptz default now()
);

create or replace function handle_new_user()
returns trigger as $$
begin
  insert into profiles (id, username, display_name)
  values (new.id, split_part(new.email,'@',1), split_part(new.email,'@',1))
  on conflict (id) do nothing;
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- 2. POSTS
create table if not exists posts (
  id               uuid default gen_random_uuid() primary key,
  user_id          uuid references profiles(id) on delete cascade not null,
  video_url        text not null,
  caption          text not null,
  tag              text not null check (tag in ('learn','chill','focus','motivate')),
  likes_count      integer default 0,
  comments_count   integer default 0,
  duration_seconds integer,
  created_at       timestamptz default now()
);
create index if not exists posts_tag_idx     on posts(tag);
create index if not exists posts_user_idx    on posts(user_id);
create index if not exists posts_created_idx on posts(created_at desc);

-- 3. LIKES
create table if not exists likes (
  id         uuid default gen_random_uuid() primary key,
  user_id    uuid references profiles(id) on delete cascade,
  post_id    uuid references posts(id)    on delete cascade,
  created_at timestamptz default now(),
  unique(user_id, post_id)
);

create or replace function increment_likes() returns trigger as $$
begin update posts set likes_count = likes_count + 1 where id = new.post_id; return new; end;
$$ language plpgsql;
drop trigger if exists on_like_insert on likes;
create trigger on_like_insert after insert on likes for each row execute procedure increment_likes();

create or replace function decrement_likes() returns trigger as $$
begin update posts set likes_count = greatest(0, likes_count - 1) where id = old.post_id; return old; end;
$$ language plpgsql;
drop trigger if exists on_like_delete on likes;
create trigger on_like_delete after delete on likes for each row execute procedure decrement_likes();

-- 4. COMMENTS
create table if not exists comments (
  id         uuid default gen_random_uuid() primary key,
  user_id    uuid references profiles(id) on delete cascade,
  post_id    uuid references posts(id)    on delete cascade,
  text       text not null,
  created_at timestamptz default now()
);
create index if not exists comments_post_idx on comments(post_id);

-- 5. FOLLOWS
create table if not exists follows (
  id           uuid default gen_random_uuid() primary key,
  follower_id  uuid references profiles(id) on delete cascade,
  following_id uuid references profiles(id) on delete cascade,
  created_at   timestamptz default now(),
  unique(follower_id, following_id)
);

create or replace function update_follow_counts_insert() returns trigger as $$
begin
  update profiles set followers_count = followers_count + 1 where id = new.following_id;
  update profiles set following_count = following_count + 1 where id = new.follower_id;
  return new;
end;
$$ language plpgsql;
drop trigger if exists on_follow_insert on follows;
create trigger on_follow_insert after insert on follows for each row execute procedure update_follow_counts_insert();

create or replace function update_follow_counts_delete() returns trigger as $$
begin
  update profiles set followers_count = greatest(0, followers_count-1) where id = old.following_id;
  update profiles set following_count = greatest(0, following_count-1) where id = old.follower_id;
  return old;
end;
$$ language plpgsql;
drop trigger if exists on_follow_delete on follows;
create trigger on_follow_delete after delete on follows for each row execute procedure update_follow_counts_delete();

-- 6. MESSAGES
create table if not exists messages (
  id          uuid default gen_random_uuid() primary key,
  sender_id   uuid references profiles(id) on delete cascade,
  receiver_id uuid references profiles(id) on delete cascade,
  text        text not null,
  read        boolean default false,
  created_at  timestamptz default now()
);
create index if not exists messages_pair_idx    on messages(sender_id, receiver_id);
create index if not exists messages_created_idx on messages(created_at desc);

-- 7. NOTIFICATIONS
create table if not exists notifications (
  id         uuid default gen_random_uuid() primary key,
  user_id    uuid references profiles(id) on delete cascade,
  actor_id   uuid references profiles(id) on delete cascade,
  type       text not null check (type in ('like','comment','follow')),
  post_id    uuid references posts(id) on delete cascade,
  read       boolean default false,
  created_at timestamptz default now()
);
create index if not exists notifications_user_idx on notifications(user_id);

-- 8. UPLOAD RATE LIMITING
create table if not exists upload_counts (
  user_id uuid references profiles(id) on delete cascade,
  date    date default current_date,
  count   integer default 0,
  primary key (user_id, date)
);

create or replace function check_and_increment_upload(p_user_id uuid)
returns boolean as $$
declare current_count integer;
begin
  insert into upload_counts (user_id, date, count) values (p_user_id, current_date, 1)
  on conflict (user_id, date) do update set count = upload_counts.count + 1
  returning count into current_count;
  return current_count <= 10;
end;
$$ language plpgsql security definer;

-- 9. ROW LEVEL SECURITY
alter table profiles       enable row level security;
alter table posts           enable row level security;
alter table likes           enable row level security;
alter table comments        enable row level security;
alter table follows         enable row level security;
alter table messages        enable row level security;
alter table notifications   enable row level security;
alter table upload_counts   enable row level security;

-- Profiles
create policy "profiles_select" on profiles for select using (true);
create policy "profiles_insert" on profiles for insert with check (auth.uid() = id);
create policy "profiles_update" on profiles for update using (auth.uid() = id);

-- Posts
create policy "posts_select" on posts for select using (true);
create policy "posts_insert" on posts for insert with check (auth.uid() = user_id);
create policy "posts_delete" on posts for delete using (auth.uid() = user_id);

-- Likes
create policy "likes_select" on likes for select using (true);
create policy "likes_insert" on likes for insert with check (auth.uid() = user_id);
create policy "likes_delete" on likes for delete using (auth.uid() = user_id);

-- Comments
create policy "comments_select" on comments for select using (true);
create policy "comments_insert" on comments for insert with check (auth.uid() = user_id);
create policy "comments_delete" on comments for delete using (auth.uid() = user_id);

-- Follows
create policy "follows_select" on follows for select using (true);
create policy "follows_insert" on follows for insert with check (auth.uid() = follower_id);
create policy "follows_delete" on follows for delete using (auth.uid() = follower_id);

-- Messages (only sender + receiver)
create policy "messages_select" on messages for select using (auth.uid() = sender_id or auth.uid() = receiver_id);
create policy "messages_insert" on messages for insert with check (auth.uid() = sender_id);

-- Notifications (only recipient)
create policy "notifications_select" on notifications for select using (auth.uid() = user_id);
create policy "notifications_update" on notifications for update using (auth.uid() = user_id);

-- Upload counts (own only)
create policy "upload_counts_select" on upload_counts for select using (auth.uid() = user_id);

-- 10. REALTIME (enable for messages)
alter publication supabase_realtime add table messages;

-- ============================================================
-- STORAGE SETUP (do this in Supabase Dashboard > Storage)
-- 1. Create bucket: videos
-- 2. Set to Public
-- 3. Set max file size: 10485760 (10MB)
-- ============================================================
